%% This code is to perform a K-means Clustering on the original matrix as a benchmark 
%  and then use PCA for visualization
clear; 
clc
rng(0)

load("2DtensorX.mat")
k = 4; 
[idx, C] = kmeans(tensorX, k, 'Distance', 'sqeuclidean', 'Replicates', 5);
[coeff1, score1, latent1] = pca(tensorX);

% Plot the Clusters using the first two principal components
figure (6);
gscatter(score1(:,1), score1(:,2), idx, "rkgb", "o*h+", 4);
xlabel('Principal Component 1');
ylabel('Principal Component 2');
title('PCA Visualization of K-means Clustering with k = 4');
legend('Cluster 1','Cluster 2','Cluster 3','Cluster 4');  % ,'Cluster 5','Cluster 6','Cluster 7','Cluster 8'

%%
load("U1.mat")
load("topclusterIdx.mat") 
[coeff2, score2, latent2] = pca(U1);
figure (2);
gscatter(score2(:,1), score2(:,2), topclusterIdx, "rkgbymcw", "o*h+.sdx", 4); 
xlabel('Principal Component 1');
ylabel('Principal Component 2');
title('PCA Visualization of K-means Clustering with k = 8');
% legend('Cluster 1','Cluster 2','Cluster 3','Cluster 4','Cluster 5','Cluster 6','Cluster 7','Cluster 8');
