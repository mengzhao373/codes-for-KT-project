
% Sample 100x200 binary matrix (0 and 1)
a = tensorX(1,:,:);
matrix = reshape(a, [294, 178]);

% % Example drug and condition names (replace with your actual data)
% drugNames_178 = arrayfun(@(n) ['Drug ' num2str(n)], 1:178, 'UniformOutput', false);  % 100 drug names
% condiNames_294 = arrayfun(@(n) ['Condition ' num2str(n)], 1:294, 'UniformOutput', false);  % 200 condition names
set(0, 'defaultfigurecolor', 'w')
% Plot the matrix using imagesc
imagesc(matrix);

% Set axis properties for better visualization
axis equal;            % Equal scaling for x and y axis
axis tight;            % Remove excess white space

% Define a custom colormap: [Gray for 0; Black for 1]
colormap([0.8 0.8 0.8; 0 0 0]);  % Gray [0.8, 0.8, 0.8] and Black [0 0 0]

% Adjust color scaling to map 0 to gray and 1 to black
caxis([0 1]);

% Add labels for x-axis and y-axis
ylabel('Conditions', 'FontSize', 16);   % Label for x-axis
xlabel('Drug ingredients', 'FontSize', 16);        % Label for y-axis

% Set custom x-tick and y-tick labels based on drugs and conditions
set(gca, 'XTick', 1:294, 'XTickLabel', drugNames_178, 'XTickLabelRotation', 90);  % Rotate x-tick labels for better readability
set(gca, 'YTick', 1:178, 'YTickLabel', condiNames_294);

% Optionally, limit the number of ticks displayed (if too crowded)
set(gca, 'YTick', 1:4:294);  % Display every 10th condition
set(gca, 'XTick', 1:4:178);  % Display every 10th drug
% set(gca, 'FontSize', 12); 


%%
dataVector = U3(:);  % Example data between 0 and 1, replace with your actual data

% Plot the histogram
histogram(dataVector, 5);  % 10 bins for better visualization, you can adjust this

% Add labels to the axes
xlabel('Value');
ylabel('Frequency');
title('Distribution of Values in the 100x1 Vector');

% Optionally, set axis limits if needed (e.g., to ensure it's between 0 and 1)
xlim([0 0.5]);


%%
nonZeroCounts = sum(U2 > 0.01);  
% Calculate the non-zero value ratio for each column
nonZeroRatios = nonZeroCounts / 100;  % Divide by the number of rows (100)
% Display the result
disp('Non-zero value ratios for each column:');
disp(nonZeroRatios);