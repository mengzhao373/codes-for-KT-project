%% This is the main code for the whole project including: %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% 1. Add toolboxes needed and connect database 
% 2. read data and pre-processing
% 3. construct 3D tensorX1 with drug not-grouped
% 4. construct 3D tensorX2 with drug groupled
% 5. non-negative TD, subtypes discovery and visualization
% 6. classification task

% 7. benchmarks - k-means clustering using the vectorized condition-drug data
%               - svm/rm/ classifying using the vectorized condition-drug data

%% 1. Add toolboxes needed and connect database
clc; clear; close all;
addpath("C:\Program Files\MATLAB\R2024a\toolbox\cvx");
addpath("C:\Program Files\MATLAB\R2024a\toolbox\tensor_toolbox");
addpath("C:\Program Files\MATLAB\R2024a\toolbox\poblano_toolbox-main");
addpath("C:\Program Files\MATLAB\R2024a\toolbox\natsortrows");

% SQL server config 
javaaddpath("C:\Program Files\MATLAB\R2024a\java\jar\mssql-jdbc-12.6.1.jre8.jar"); 
databasename = "esrd_phenotype";  
username = "MC\mz3048";
password = "QWERTYuiop3731995."; 
driver = "com.microsoft.sqlserver.jdbc.SQLServerDriver";
url = "jdbc:sqlserver://elilex.dbmi.columbia.edu; database=esrd_phenotype; integratedSecurity=true; encrypt=true; trustServerCertificate=true;";
conn = database(databasename, username, password, driver, url);  
conn.Message

%% 2. Read data from esrd_phenotype database and pre-processing %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% select concept_id from ConditionsFrequency with freq_pct in 0.1-1
query1 = 'SELECT concept_id,concept_name FROM dbo.ConditionsFrequency_OntologyAugmented_selByDesc_removNoMeaning_v2 WHERE frequency_pct BETWEEN 0.1 AND 1';   
curs1 = exec(conn, query1);
curs1 = fetch(curs1); 
condIDName = curs1.Data;     
condIDs = condIDName(:,1); % 591->531
condIDsStr = strjoin(string([condIDs{:}]), ',');

% select person_id from ConditionsInVisit with selected concept_ids 
query2 = sprintf('SELECT person_id,concept_id,concept_name FROM dbo.ConditionsInVisit_OntologyAugmented_selByDesc_removNoMeaning_v2 WHERE concept_id IN (%s)', condIDsStr);
curs2 = exec(conn, query2);
curs2 = fetch(curs2);
condTable = curs2.Data(:,1:2);  
condiName = curs2.Data(:,2:3);

% counts of condition for each patient
condPplIDs = condTable(:,1);                    
[uniPplCond, ~, idx] = unique(vertcat(condPplIDs{:}));  
condCount = accumarray(idx, 1);  

% select concept_id from DrugIngredientsFrequency with frequency_pct in 0.1-1 
query3 = 'SELECT concept_id FROM dbo.DrugIngredientsFrequency_OntologyAugmented_v2 WHERE frequency_pct BETWEEN 0.05 AND 1';
curs3 = exec(conn, query3);
curs3 = fetch(curs3);
drugIDs = curs3.Data;             % 211 272                   
drugIDsStr = strjoin(string([drugIDs{:}]), ',');                            

% select person_id from DrugIngredientsInVisit with selected concept_ids 
query4 = sprintf('SELECT person_id,concept_id,concept_name FROM dbo.DrugIngredientsInVisit_OntologyAugmented_v2 WHERE concept_id IN (%s)', drugIDsStr);
curs4 = exec(conn, query4);
curs4 = fetch(curs4); 
drugTable = curs4.Data(:,1:2);  
drugName = curs4.Data(:,2:3); 

% counts of drug for each patient
drugPplIDs = drugTable(:,1);         
[uniPplDrug, ~, idx] = unique(vertcat(drugPplIDs{:})); 
drugCount = accumarray(idx, 1);          

% get the common person_id from condition and drug
uniPplIDsTensor = intersect(uniPplCond, uniPplDrug);  % 2617

% remove all genitourinary codes
condGenitouri = readmatrix("kidney_findings_genitourinary_codes.csv"); 
condGenitouri = condGenitouri(2:end, 2);
not_in_all_condIDs = ~ismember(cell2mat(condIDs), condGenitouri);
new_condIDs = condIDs(not_in_all_condIDs);
removed_condIDs = condIDs(~not_in_all_condIDs);
condIDs = new_condIDs; 

% print the results
% for i = 1:length(uniPplCond)
%     fprintf('Person %d occurs %d times of condition codes\n', uniPplCond(i), condCount(i)); 
% end
% for i = 1:length(uniPplDrug)
%     fprintf('Person %d occurs %d times of drugs codes\n', uniPplDrug(i), drugCount(i)); 
% end

% % plot the distribution of cond/drug counts
% figure(1)
% histogram(condCount, 'Normalization', 'probability');
% xlabel('Number of Samples');
% ylabel('Probability');
% title('Distribution of Sample Counts');
% figure(2)
% histogram(drugCount, 'Normalization', 'probability');
% xlabel('Number of Samples');
% ylabel('Probability');
% title('Distribution of Sample Counts');

%% 3. Construct a 3D tensor with drug not-grouped %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
all_condIDs = cell2mat(condTable(:,2));
all_drugIDs = cell2mat(drugTable(:,2));
K = length(uniPplIDsTensor);         % 2617
I = length(condIDs);                 % 331(308) 591
J = length(drugIDs);                 % 211      272 
tensorX = zeros(K, I, J);
for k = 1:K
    tempPplIDs = uniPplIDsTensor(k);
    % find all drug_ids and condition_ids for this person_id
    pplCondIDs = all_condIDs(ismember(cell2mat(condTable(:,1)), tempPplIDs));
    pplDrugIDs = all_drugIDs(cell2mat(drugTable(:,1)) == tempPplIDs);
    % check for each drug_cpt_id and condition_cpt_id combination
    for i = 1:I
        for j = 1:J   
            tensorX(k, i, j) = any(ismember(pplDrugIDs, cell2mat(drugIDs(j)))) && any(ismember(pplCondIDs, cell2mat(condIDs(i))));
        end
    end
end  
% save('3DtensorX1_moreConditions.mat', 'tensorX', '-v7.3');

%% 4. Construct a 3D tensor with drug groupled %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
all_condIDs = cell2mat(condTable(:,2));
all_drugIDs = cell2mat(drugTable(:,2));
drug_group_list = readmatrix("drug_group_list.xlsx");
numDrugGroup = 24;
drug_groups = cell(1, numDrugGroup);
for i = 1:numDrugGroup
    drug_groups{i} = num2str(i); % Populate the cell array with string representations of numbers
end
K = length(uniPplIDsTensor);         % 2617
I = length(condIDs);                 % 331
J = numDrugGroup;                              % 211
tensorX = zeros(K, I, J);
numDrugGroup = 1:30;
for k = 1:K
    tempPplIDs = uniPplIDsTensor(k);
    % find all drug_ids and condition_ids for this person_id
    pplCondIDs = all_condIDs(ismember(cell2mat(condTable(:,1)), tempPplIDs));
    pplDrugIDs = all_drugIDs(cell2mat(drugTable(:,1)) == tempPplIDs);
    new_pplDrugIDs = NaN(length(pplDrugIDs), 2);
    for ij = 1:length(pplDrugIDs)
        % Get the current drug ID
        currentDrugID = pplDrugIDs(ij);
        % Find the index of the drug ID in drug_list
        idx = find(drug_group_list(:, 1) == currentDrugID);
        new_pplDrugIDs(ij, :) = [currentDrugID, drug_group_list(idx, 2)]; 
    end
    % Extract the cluster numbers from the new_pplDrugIDs matrix
    clusters = new_pplDrugIDs(:, 2);   
    % Count the occurrences of each cluster
    [uniqueClusters, ~, clusterIndices] = unique(clusters);
    clusterCounts = accumarray(clusterIndices, 1);
    % Create a summary table with cluster numbers and their counts
    clusterSummary = [uniqueClusters, clusterCounts];
    % check for each drug_cpt_id and condition_cpt_id combination
    for i = 1:I
        for j = 1:J   
            tensorX(k, i, j) = any(ismember(new_pplDrugIDs(:, 2), numDrugGroup(j))) && any(ismember(pplCondIDs, cell2mat(condIDs(i))));
        end
    end
end  
save('3DtensorX2_moreCondition.mat', 'tensorX', '-v7.3');

%% 5. Non-negative TD and subtypes discovery and visualization %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% load("3DtensorX1_groupedDrugs.mat")
R = 4; 
options.alg = "pdnr";
[M1, ~, Output1] = cp_apr(tensor(tensorX), R, options);    
U1 = M1.U{1};
U2 = M1.U{2};
U3 = M1.U{3};
Lambda = M1.lambda;
figure(3)
plot(Output1.fnEvals); 
figure(4)
plot(Output1.nInnerIters);
figure(5)
plot(Output1.kktViolations);

% Extracted condition and drug phenotypes analysis
noTopPheno = 20;
topValuesCondi = zeros(noTopPheno, R);
topIndicesCondi = zeros(noTopPheno, R);
topValuesDrug = zeros(noTopPheno, R);
topIndicesDrug = zeros(noTopPheno, R);
topCondiID = cell(noTopPheno, R);
topDrugID = cell(noTopPheno, R); 
topCondiNames = cell(size(topCondiID));
topDrugNames = cell(size(topDrugID));

% loop through each column/phenotype
for i = 1:R     
    [topValuesCondi(:,i), topIndicesCondi(:,i)] = maxk(U2(:,i), noTopPheno);% condition
    [topValuesDrug(:,i), topIndicesDrug(:,i)] = maxk(U3(:,i), noTopPheno);  % drug
    for j = 1:size(topIndicesCondi, 1) % loop through each of the top indices
        topCondiID{j, i} = condIDs{topIndicesCondi(j, i)}; % condition
        topDrugID{j, i} = drugIDs{topIndicesDrug(j, i)}; 
    end
end
% calculate the ratio of each col
per_ratio2 = zeros(noTopPheno, R);
per_ratio3 = zeros(noTopPheno, R);
for col = 1:R
    sum2 = sum(U2(:,col));
    sum3 = sum(U3(:,col));
    per_ratio2(:,col) = (topValuesCondi(:,col)./sum2)*100;
    per_ratio3(:,col) = (topValuesDrug(:,col)./sum3)*100;
end

% get the name of the selected top condition/drug
for col = 1:R
    for row = 1:noTopPheno
        currentID = topCondiID{row, col};    % current diagnosis ID  
        idx = find([condiName{:,1}] == currentID, 1, 'first'); 
        topCondiNames{row, col} = condiName{idx, 2}; 
        currentID = topDrugID{row, col};     % current diagnosis ID  
        idx = find([drugName{:,1}] == currentID, 1, 'first'); 
        topDrugNames{row, col} = drugName{idx, 2}; 
    end
end

% word cloud visualzation
wordCloudResult(topCondiNames, per_ratio2, R)
wordCloudResult(topDrugNames, per_ratio3, R)

% result of each patient belong to which cluster
I = size(U1, 1);  % 2617 
cluster = 1;
patient_cluster = zeros(I, cluster);
topclusterIdx = zeros(I, cluster);
[sortedVal, sortedIDX] = sort(U1, 2, 'descend');
for i = 1:I
    for j = 1:cluster
        patient_cluster(i,j) = sortedVal(i,j);
        topclusterIdx(i,j) = sortedIDX(i,j);
    end   
end

% TSNE-Visualization
visualization_tsne(U1, topclusterIdx)

% writematrix(topValuesCondi, 'topValuesCondition_July24.csv');
% writematrix(topValuesDrug, 'topValuesDrug_July24.csv');
% writecell(topCondiNames, 'topConditionNames_July24.csv');
% writecell(topDrugNames, 'topDrugNames_July24.csv');

%% Classification using label information  %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% read the lable table 1-yr, 3-yr, 5-yr, 7-yr, 10-yr
queryLable00 = 'SELECT * FROM dbo.outcomes_30_days_single_label_most_severe_v2';
queryLable0 = 'SELECT * FROM dbo.outcomes_90_days_single_label_most_severe_v2';   % 90-day
queryLable1 = 'SELECT * FROM dbo.outcomes_365_days_single_label_most_severe_v2';  % 1-yr
queryLable2 = 'SELECT * FROM dbo.outcomes_1095_days_single_label_most_severe_v2'; % 3-yr
queryLable3 = 'SELECT * FROM dbo.outcomes_1825_days_single_label_most_severe_v2'; % 5-yr
queryLable4 = 'SELECT * FROM dbo.outcomes_2555_days_single_label_most_severe_v2'; % 7-yr
queryLable5 = 'SELECT * FROM dbo.outcomes_3650_days_single_label_most_severe_v2'; % 10-yr 

curs100 = exec(conn, queryLable00);
label00 = fetch(curs100); 
label00 = label00.Data; label = label00(:,2:3);
save("label00.mat", "label")
curs10 = exec(conn, queryLable0);
label0 = fetch(curs10); 
label0 = label0.Data; label = label0(:,2:3);
save("label0.mat", "label")  % 2550
curs11 = exec(conn, queryLable1);
label1 = fetch(curs11); 
label1 = label1.Data; label = label1(:,2:3);
save("label1.mat", "label")  % 2494
curs21 = exec(conn, queryLable2);
label2 = fetch(curs21); 
label2 = label2.Data; label = label2(:,2:3); 
save("label2.mat", "label")  % 2352
curs3 = exec(conn, queryLable3);
label3 = fetch(curs3); 
label3 = label3.Data; label = label3(:,2:3);  
save("label3.mat", "label")  % 2113
curs4 = exec(conn, queryLable4);
label4 = fetch(curs4); 
label4 = label4.Data; label = label4(:,2:3);  
save("label4.mat", "label")  % 1907
curs5 = exec(conn, queryLable5);
label5 = fetch(curs5); 
label5 = label5.Data; label = label5(:,2:3); 
save("label5.mat", "label")  % 1540

%% train the classification models using all the unbalanced samples %%%%%%%%%%%%%%%%%%%%%%%%
% label distribution: 
% 30    90    1     3      5      7       10
% 2540	2446  2233	1874   1492	  1156	  617
% 28	104	  261	478	   621	  751	  923

% 5: 827  239+112+770 = 1121    1513  905      
rng(0)
numLable1 = 905;                            
Data = U1;   
currentLabel = load("label4.mat");  % 00 0 1 2 3 4 5       
labelTable = cell2mat(currentLabel.label); % 2494*2  ID and belong to which label
logicalIdx = ismember(labelTable(:,1), uniPplIDsTensor); % find rows where ID column are in uniPplIDsCoupled 
Label = labelTable(logicalIdx, 2);         % 2494*1 
Label_ID = labelTable(logicalIdx, 1);
Label(Label == 3) = 2;                     % Merge class 3 into class 2
Label(Label == 4) = 2;                     % Merge class 4 into class 3

% Extract sample IDs with labels and filter the tensor data
labeledIDs = labelTable(:, 1);
filtered_U1 = zeros(size(labelTable, 1), R);
counter = 1;
for i = 1:length(uniPplIDsTensor)  % Loop through each ID in uniPplIDsTensor
    % Find the index in labeledIDs that matches the current ID from uniPplIDsTensor
    idx = find(labeledIDs == uniPplIDsTensor(i));
    % Check if the current ID from uniPplIDsTensor has a corresponding label
    if ~isempty(idx)
        % If a match is found, add the corresponding data row to filteredData
        filtered_U1(counter, :) = Data(i, :);
        counter = counter + 1;
    end
end
filtered_U1 = filtered_U1(1:counter-1, :); % 2494*4

% Find indices for each label
idxLab1 = find(Label == 1);  
idxLab2 = find(Label == 2);  
idxLab3 = find(Label == 3);
% Randomly select numLable1 samples from the indices where Label is 1
selectedIdx1 = idxLab1(randperm(length(idxLab1), numLable1));
% Concatenate the selected indices for label 1 with all indices of labels 2 and 3
finalIndices = [selectedIdx1; idxLab2];  
% Use the concatenated indices to filter 'filteredData'
finalData = filtered_U1(finalIndices, :);
% Optionally, filter the labels as well if you need them for further analysis
finalLabels = Label(finalIndices);
finalLabels_ID = Label_ID(finalIndices);

% Split the data into training (80%) and testing (20%) sets-balanced sample
cv = cvpartition(size(finalData, 1), 'HoldOut', 0.2);
% Indexes for training and testing sets
trainIdx = cv.training;
testIdx = cv.test;
% Separate the data into training and testing sets
XTrain = finalData(trainIdx, :);
YTrain = finalLabels(trainIdx);
XTest = finalData(testIdx, :);
YTest = finalLabels(testIdx);

models = {'Naive Bayes', 'Random Forest', 'SVM'};

% 1 Train a model cnb model
model = fitcnb(XTrain, YTrain, 'Distribution', 'kernel');
[nb_pred,  nb_scores] = predict(model, XTest);

% 2 Train a random forest  model
model = TreeBagger(100, XTrain, YTrain, 'Method', 'classification');
[YPred, rf_scores] = predict(model, XTest);
rf_pred = str2double(YPred);

% 3 Train and evaluate SVM
svm_model = fitcsvm(XTrain, YTrain, 'KernelFunction', 'linear', 'Standardize', true);
[svm_pred, svm_scores] = predict(svm_model, XTest);


predictions = {rf_pred, svm_pred, nb_pred};
scores = {rf_scores(:, 2), svm_scores(:, 2), nb_scores(:, 2)};

for i = 1:length(models)
    % Get predictions and scores
    pred = predictions{i};
    score = scores{i};
    
    % Calculate metrics
    [accuracy, precision, recall, f1_score] = calc_precision_recall_f1(YTest, pred);
    [X, Y, T, AUC] = perfcurve(YTest, score, 1);

    % Display results
    fprintf('%s:\n', models{i});
    fprintf('Accuracy: %.2f\n', accuracy);
    fprintf('Precision: %.2f\n', precision);
    fprintf('Recall: %.2f\n', recall);
    fprintf('F1-score: %.2f\n', f1_score);
    fprintf('AUC: %.2f\n\n', AUC);
end


%% calculate the distribution of outcome in each cluster -- only 2 outcomes
Label = cell2mat(label00(:,2:3)); % 2550*2
% Label(Label == 3) = 2;                     % Merge class 3 into class 2
% Label(Label == 4) = 2;  
ppl_id_and_clusters = [uniPplIDsTensor, topclusterIdx]; % 2617*2: ID and belong to which cluster
[~, ia, ib] = intersect(ppl_id_and_clusters(:,1), Label(:,1));
new_id_and_clusters = ppl_id_and_clusters(ia, :); % 2550*2

id_cluster_label = [new_id_and_clusters, Label(:,2)];

% Extract clusters and labels
data = id_cluster_label;
clusters = data(:, 2);
labels = data(:, 3);
% Find unique clusters
unique_clusters = unique(clusters);

% Initialize arrays to hold results
cluster_counts = zeros(length(unique_clusters), 1);
label0_ratios = zeros(length(unique_clusters), 1);
label1_ratios = zeros(length(unique_clusters), 1);

% Loop over each unique cluster
for i = 1:length(unique_clusters)
    cluster_id = unique_clusters(i);  % 1 2 3 4
    % Get the indices for the current cluster
    cluster_indices = (clusters == cluster_id);
    % Count the number of samples in the current cluster
    cluster_counts(i) = sum(cluster_indices);
    % Get the labels for the current cluster
    cluster_labels = labels(cluster_indices);
    % Calculate the ratio of label 0 and label 1
    num_label0 = sum(cluster_labels == 1);
    num_label1 = sum(cluster_labels == 2);
    total_labels = num_label0 + num_label1;
    label0_ratios(i) = num_label0 / total_labels;
    label1_ratios(i) = num_label1 / total_labels;
end
% Display the results
disp('Cluster : Count : Label 1 Ratio : Label 2 Ratio');
for i = 1:length(unique_clusters)
    fprintf('Cluster %d : %d samples : %.2f (Label 1) : %.2f (Label 2)\n', unique_clusters(i), cluster_counts(i), label0_ratios(i), label1_ratios(i));
end


%%  -- 4 outcomes
load("label1.mat")

Label = cell2mat(label(:,1:2)); % 2550*2 
% Label(Label == 3) = 2;                     % Merge class 3 into class 2
% Label(Label == 4) = 2;  
ppl_id_and_clusters = [uniPplIDsTensor, topclusterIdx]; % 2617*2: ID and belong to which cluster
[~, ia, ib] = intersect(ppl_id_and_clusters(:,1), Label(:,1));
new_id_and_clusters = ppl_id_and_clusters(ia, :); % 2550*2

id_cluster_label = [new_id_and_clusters, Label(:,2)];

% Extract clusters and labels
data = id_cluster_label;
clusters = data(:, 2);
labels = data(:, 3);
% Find unique clusters
unique_clusters = unique(clusters);

% Initialize arrays to hold results
cluster_counts = zeros(length(unique_clusters), 1);
label_ratios = zeros(length(unique_clusters), 4); % For labels 1, 2, 3, and 4

% Loop over each unique cluster
for i = 1:length(unique_clusters)
    cluster_id = unique_clusters(i);
    
    % Get the indices for the current cluster
    cluster_indices = (clusters == cluster_id);
    
    % Count the number of samples in the current cluster
    cluster_counts(i) = sum(cluster_indices);
    
    % Get the labels for the current cluster
    cluster_labels = labels(cluster_indices);
    
    % Calculate the ratio of each label
    for label = 1:4
        num_label = sum(cluster_labels == label);
        label_ratios(i, label) = num_label / cluster_counts(i);
    end
end

% Display the results
disp('Cluster : Count : Label 1 Ratio : Label 2 Ratio : Label 3 Ratio : Label 4 Ratio');
for i = 1:length(unique_clusters)
    fprintf('Cluster %d : %d samples : %.2f (Label 1) : %.2f (Label 2) : %.2f (Label 3) : %.2f (Label 4)\n', ...
        unique_clusters(i), cluster_counts(i), label_ratios(i, 1), label_ratios(i, 2), label_ratios(i, 3), label_ratios(i, 4));
end


