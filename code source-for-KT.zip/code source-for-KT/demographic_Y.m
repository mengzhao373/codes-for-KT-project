%% Construct the matrix Y using additional features %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
clc; clear; close all;
addpath("C:\Program Files\MATLAB\R2024a\toolbox\cvx");
addpath("C:\Program Files\MATLAB\R2024a\toolbox\tensor_toolbox");
addpath("C:\Program Files\MATLAB\R2024a\toolbox\poblano_toolbox-main");
addpath("C:\Program Files\MATLAB\R2024a\toolbox\natsortrows");

% SQL server config 
javaaddpath("C:\Program Files\MATLAB\R2024a\java\jar\mssql-jdbc-12.6.1.jre8.jar"); 
databasename = "esrd_phenotype";  
username = "username";
password = "password"; 
driver = "com.microsoft.sqlserver.jdbc.SQLServerDriver";
url = "jdbc:sqlserver://elilex.dbmi.columbia.edu; database=esrd_phenotype; integratedSecurity=true; encrypt=true; trustServerCertificate=true;";
conn = database(databasename, username, password, driver, url);  
conn.Message

%% get age and gender features
query_y = 'SELECT * FROM dbo.KidneyTransplantCohort_final_v2'; % KidneyTransplantCohort_cleaned_adult
curs_y = exec(conn, query_y);
curs_y = fetch(curs_y); 
idAgeGender = curs_y.Data(:, [1, 7, 8, 9, 10]);
idAgeGender = cell2mat(idAgeGender);

%% keep the common id 
% Extract the sample IDs from idAgeGender
load('uniPplIDsTensor')
load("topclusterIdx-patientCluster.mat")
sampleIDs = idAgeGender(:, 1);
% Find the rows in idAgeGender where the sample ID is in uniPplIDsTensor
[isInUniPplIDs, idx] = ismember(sampleIDs, uniPplIDsTensor);
% Filter the rows
filIdAgeGender = idAgeGender(isInUniPplIDs, :);
% Optionally, sort the filteredIdAgeGender to match the order of uniPplIDsTensor
[~, sortIdx] = sort(idx(isInUniPplIDs));
filIdAgeGender = filIdAgeGender(sortIdx, :);
filIdAgeGender = [filIdAgeGender, topclusterIdx];

% change the gender code to 1 or 0 8507 is 1/Male
colGender = filIdAgeGender(:, 3);
for i = 1:length(colGender)
    if colGender(i) == 8507
        filIdAgeGender(i, 3) = 1;
    else  
        filIdAgeGender(i, 3) = 0;
    end
end

%% turn age into 4 class [<40,41-59,60-69,>70]
% Extract the age column
ages = filIdAgeGender(:, 2);
% Classify ages into categories
ageClasses = zeros(size(ages));
ageClasses(ages < 40) = 1;               % Younger than 40
ageClasses(ages >= 40 & ages <= 59) = 2; % Between 40-59
ageClasses(ages >= 60 & ages <= 69) = 3; % Between 60-69
ageClasses(ages >= 70) = 4;              % Older than 70
% Replace the age column in the original matrix with age classes
filIdAgeGender(:, 2) = ageClasses;

%% calculate the distribution of each cluster -- age, gender, race 
% Assuming your matrix is named 'dataMatrix' and is 2617x5
% Column 1: Sample ID
% Column 2: Age Class (1, 2, 3, or 4) [<40,41-59,60-69,>70]
% Column 3: Gender (1 for male, 0 for female)
% Column 4: Race (8527, 8516, 8515, 8522, or 0)
% Column 5: Cluster (1, 2, 3, or 4)
dataMatrix = filIdAgeGender;
ageClasses = dataMatrix(:, 2);
genders = dataMatrix(:, 3);
races = dataMatrix(:, 4);
ethi = dataMatrix(:, 5);
clusters = dataMatrix(:, 6);

% Unique clusters
uniqueClusters = unique(clusters);
numClusters = length(uniqueClusters);

% Initialize results
ageDistribution = zeros(numClusters, 4);    % 4 age classes
genderDistribution = zeros(numClusters, 2); % 2 genders (male, female)
raceDistribution = zeros(numClusters, 5);   % 5 races (8527, 8516, 8515, 8522, 0)
ethiDistribution = zeros(numClusters, 3);   % 5 ethi (38003564  0 38003563)

% Calculate distributions for each cluster
for i = 1:numClusters
    clusterID = uniqueClusters(i);
    clusterIndices = (clusters == clusterID);    
   
    % Age class distribution
    for ageClass = 1:4
        ageDistribution(i, ageClass) = sum(ageClasses(clusterIndices) == ageClass);% / sum(clusterIndices);
    end
    
    % Gender distribution
    genderDistribution(i, 1) = sum(genders(clusterIndices) == 1) ;%/ sum(clusterIndices); % Male ratio
    genderDistribution(i, 2) = sum(genders(clusterIndices) == 0) ;%/ sum(clusterIndices); % Female ratio
    
    % Race distribution
    uniqueRaces = [8527, 8516, 8515, 8522, 0];
    for j = 1:length(uniqueRaces)
        raceDistribution(i, j) = sum(races(clusterIndices) == uniqueRaces(j));% / sum(clusterIndices);
    end

    % ethinity
    uniqueEthi = [38003563, 38003564, 0];
    for j = 1:length(uniqueEthi)
        ethiDistribution(i, j) = sum(ethi(clusterIndices) == uniqueEthi(j));% / sum(clusterIndices);
    end

end

% Display results
for i = 1:numClusters
    fprintf('Cluster %d:\n', uniqueClusters(i));
    fprintf('Age Class Distribution:\n');
    
    for ageClass = 1:4
        fprintf('Age Class %d: %.2f%%\n', ageClass, ageDistribution(i, ageClass) * 100);
    end
    fprintf('Gender Distribution:\n');
    fprintf('Male: %.2f%%\n', genderDistribution(i, 1) * 100);
    fprintf('Female: %.2f%%\n', genderDistribution(i, 2) * 100);
    fprintf('Race Distribution:\n');
    for j = 1:length(uniqueRaces)
        fprintf('    Race %d: %.2f%%\n', uniqueRaces(j), raceDistribution(i, j) * 100);
    end

    fprintf('Ethi Distribution:\n');
    for j = 1:length(uniqueEthi)
        fprintf('    Race %d: %.2f%%\n', uniqueEthi(j), ethiDistribution(i, j) * 100);
    end
    fprintf('\n');
end

%% statistic analysis for age
age_data = ageDistribution;
% Calculate row and column sums
row_totals = sum(age_data, 2);   % Row totals (sum across each cluster)
col_totals = sum(age_data, 1);   % Column totals (sum across each age group)
total = sum(row_totals);         % Grand total (total number of patients)
% Calculate expected frequencies
expected = (row_totals * col_totals) / total;
% Display the expected frequencies
disp('Expected Frequencies:');
disp(expected);
% Compute Chi-square statistic
chi2_stat = sum(sum((age_data - expected).^2 ./ expected));
% Degrees of freedom
[rows, cols] = size(age_data);
df = (rows - 1) * (cols - 1);
% Calculate p-value
p_value = 1 - chi2cdf(chi2_stat, df);

% Display result
disp(['Chi-square statistic for age categories: ', num2str(chi2_stat)]);
disp(['Degrees of freedom: ', num2str(df)]);
disp(['p-value for age distribution: ', num2str(p_value)]);

%% [Male, Female] for each group 
sex_group1 = [600, 278]; 
sex_group2 = [238, 104];
sex_group3 = [968, 649];
sex_group4 = [205, 172];

% Create a contingency table
sex_data = [sex_group1; sex_group2; sex_group3; sex_group4];

% Perform Chi-square test
[p_sex, chi2_stat_sex, df_sex] = chi2cont(sex_data);

% Display the result
disp(['p-value from Chi-Square Test for Sex: ', num2str(p_sex)]);

%% race 
race_group1 = raceDistribution(1,:); 
race_group2 = raceDistribution(2,:); 
race_group3 = raceDistribution(3,:); 
race_group4 = raceDistribution(4,:); 
% Create a contingency table
race_data = [race_group1; race_group2; race_group3; race_group4];
% Perform Chi-square test
[p_race, ~, ~] = chi2cont(race_data);
% Display the result
disp(['p-value from Chi-Square Test for Race: ', num2str(p_race)]);

%% ethinicity
eth_group1 = ethiDistribution(1,:); 
eth_group2 = ethiDistribution(2,:); 
eth_group3 = ethiDistribution(3,:); 
eth_group4 = ethiDistribution(4,:);
% Create a contingency table
eth_data = [eth_group1; eth_group2; eth_group3; eth_group4];
% Perform Chi-square test
[p_eth, chi2_stat_eth, df_eth] = chi2cont(eth_data);

% Display the result
disp(['p-value from Chi-Square Test for eth: ', num2str(p_eth)]);

%% conditions and diagonoses
group1_icd = topDrugID(:,1);
group2_icd = topDrugID(:,2);
group3_icd = topDrugID(:,3);
group4_icd = topDrugID(:,4);

% Combine all ICD codes and group labels
all_icd = [group1_icd, group2_icd, group3_icd, group4_icd];
[p_race, chi2_stat_race, df_race] = chi2cont(cell2mat(all_icd));
% Display the result
disp(['p-value from Chi-Square Test for Race: ', num2str(p_race)]);

%% avaerage age
data = [ages, clusters]; % age is not cateroized 
% Get the unique cluster numbers
clusters = unique(data(:, 2));
% Initialize a variable to store the average age for each cluster
average_age = zeros(length(clusters), 1);
std_age = zeros(length(clusters), 1);
% Loop through each cluster and calculate the average age
for i = 1:length(clusters)
    cluster_data = data(data(:, 2) == clusters(i), 1);  % Get ages of patients in the current cluster
    average_age(i) = mean(cluster_data);  % Calculate the average age for the current cluster
    std_age(i) = std(cluster_data);
end
% Display the average age for each cluster
for i = 1:length(clusters)
    fprintf('Cluster %d - Average Age: %.2f, Standard Deviation: %.2f\n', clusters(i), average_age(i), std_dev_age(i));
end

%% age numbers statistic
% Initialize cell array to store ages for each cluster
groups = cell(1, 4);
% Loop through the cluster numbers (1 to 4)
for cluster = 1:4
    % Extract the ages for the current cluster
    groups{cluster} = data(data(:, 2) == cluster, 1);
end

group1_ages = groups{1}';  % Ages for group 1
group2_ages = groups{2}';  % Ages for group 2
group3_ages = groups{3}';  % Ages for group 3
group4_ages = groups{4}';  % Ages for group 4

% Combine data into one vector and create a group label vector
ages = [group1_ages, group2_ages, group3_ages, group4_ages];
group_labels = [ones(size(group1_ages)), 2*ones(size(group2_ages)), ...
                3*ones(size(group3_ages)), 4*ones(size(group4_ages))];
% Perform one-way ANOVA
[p, tbl, stats] = anova1(ages, group_labels);
% Display results
fprintf('p-value from ANOVA: %.4f\n', p);
% Optionally, perform multiple comparisons using Tukey's test
if p < 0.05
    fprintf('Performing multiple comparisons using Tukey''s test...\n');
    multcompare(stats);
end