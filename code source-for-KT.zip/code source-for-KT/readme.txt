main function include:
1. Add toolboxes needed and connect database 
2. read data and pre-processing
3. construct 3D tensorX1 without drug grouped
4. construct 3D tensorX2 with drug grouped (this is used as a test before)
5. apply non-negative TD, subtypes discovery, and visualization
6. classification task

plot_pair_condi_drug is the codes to plot an example of a patient's condition and medication pair

wordCloudResult is a function to plot the word cloud figures for the subtypes (conditions and medications)

visualization_tsne is a function to perform t-SNE for the visualization of subtypes from tensor method and K-means method

demographic_Y is the statistical results of demographics in each subtype

kmeans_benchmark is the codes for comparing with k-means as a benchmark

The Resluts-figures folder includes the results and figures for the manuscript