function wordCloudResult(topCondiNames, per_ratio2, R) 

    for i = 1:R
        words = topCondiNames(:,i);
        scores = per_ratio2(:,i);
        figure
        wordcloud(words, scores, "LayoutNum", 5);
        title(['Subtype' num2str(i)]);
    end

end