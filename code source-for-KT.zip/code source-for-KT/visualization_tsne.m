function visualization_tsne(U1, topclusterIdx)
    % Perform t-SNE
    rng(0)
    Y = tsne(U1, 'NumDimensions', 2);
    % Convert labels to numeric if they are not already
    % Ensure labels are numeric or categorical
    if ~isnumeric(topclusterIdx)
        topclusterIdx = double(categorical(topclusterIdx));
    end    
    % Get unique labels
    uniqueLabels = unique(topclusterIdx);
    
    % Create a new figure for the scatter plot
    figure (14);
    
    % Define a colormap with enough distinct colors for the unique labels
    colors = lines(length(uniqueLabels)); % 'lines' generates a matrix of colors
    
    % Plot each class with a different color
    hold on; % Allows plotting multiple scatter plots on the same figure
    for i = 1:length(uniqueLabels)
        % Get the indices of the current label
        idx = topclusterIdx == uniqueLabels(i);
        % Plot the data points for the current label
        scatter(Y(idx, 1), Y(idx, 2), 10, colors(i, :), 'filled'); % 36 is the marker size
    end
    hold off;
    
    % Add labels and title
    xlabel('t-SNE Dimension 1');
    ylabel('t-SNE Dimension 2');
    title('t-SNE Visualization of Sample Data');
    
    % Create a legend
    legend(arrayfun(@(x) sprintf('Class %d', x), uniqueLabels, 'UniformOutput', false)); 
    % Adjust the plot
    grid on;
end