% Data matrix
data = readmatrix('adverse_event_ratio.csv');

% Number of subtypes and time points
numSubtypes = 4;
numOutcomes = 3;
numTimePoints = 7;

% Preallocate a matrix for the stacked data
stackedData = zeros(numSubtypes, numOutcomes, numTimePoints);

% Fill the stacked data matrix
for t = 1:numTimePoints
    for s = 1:numSubtypes
        stackedData(s, :, t) = data((s-1)*numOutcomes+1:s*numOutcomes, t);
    end
end

% Create the stacked bar chart
figure;
hold on;
barColors = lines(numOutcomes); % Use distinct colors for each outcome

% Plotting
barWidth = 0.8;
gap = 1; % Adjust gap between sets of bars
for t = 1:numTimePoints
    for s = 1:numSubtypes
        barPosition = (t-1) * (numSubtypes + gap) + s;
        b = bar(barPosition, stackedData(s, :, t), 'stacked', 'BarWidth', barWidth);
        for k = 1:numOutcomes
            b(k).FaceColor = barColors(k,:);
        end
    end
end

% Adjust x-axis labels
xticks((numSubtypes/2 + (0:numTimePoints-1) * (numSubtypes + gap)));
xticklabels({"30-day", "90-day", "1-year", "3-year", "5-year", "7-year", "10-year"})
% xticklabels(arrayfun(@(x) sprintf('Time %d', x), 1:numTimePoints, 'UniformOutput', false));

% Add labels and title
xlabel('Time');
ylabel('Outcome ratios');
title('Stacked bar chart of outcome ratios over time');
legend(arrayfun(@(x) sprintf('Outcome %d', x), 1:numOutcomes, 'UniformOutput', false), 'Location', 'BestOutside');

hold off;